package main

import (
	"bufio"
	"fmt"
	"image/color"
	"log"
	"math/rand"
	"net"
	"strings"
	"sync"
	"time"

	"github.com/hajimehoshi/ebiten/v2"
	"github.com/hajimehoshi/ebiten/v2/ebitenutil"
	"github.com/hajimehoshi/ebiten/v2/inpututil"
	"github.com/hajimehoshi/ebiten/v2/vector"
)

const (
	screenWidth  = 800
	screenHeight = 600
	port         = "8080"
)

const titleArt = `
  ____ _     ___  ____  _____ ____  
 / ___| |   / _ \/ ___|| ____|  _ \ 
| |   | |  | | | \___ \|  _| | | | |
| |___| |__| |_| |___) | |___| |_| |
 \____|_____\___/|____/|_____|____/ 
  _____ ____   ___  _   _ _____ _     ___ _   _ _____ 
 |  ___|  _ \ / _ \| \ | |_   _| |   |_ _| \ | | ____|
 | |_  | |_) | | | |  \| | | | | |    | ||  \| |  _|  
 |  _| |  _ <| |_| | |\  | | | | |___ | || |\  | |___ 
 |_|   |_| \_\\___/|_| \_| |_| |_____|___|_| \_|_____|
`

const playerArt = `
      O
     /|\
     / \
`

const enemyArt = `
     [X]
     /T\
     / \
`

type GameState int

const (
	StateMenu GameState = iota
	StateWaiting
	StatePlaying
	StateGameOver
	StateStory
	StateHotseat
)

type Game struct {
	state       GameState
	isHost      bool
	isSingle    bool
	isHotseat   bool
	conn        net.Conn
	mu          sync.Mutex
	msgLog      []string
	inputStr    string
	myHP        int
	myMaxHP     int
	enemyHP     int
	enemyMaxHP  int
	myTurn      bool
	logLimit    int
	lastError   string
	ipInput     string
	typingIP    bool
	storyStage  int

	potions      int
	p2Potions    int
	energy       int
	p2Energy     int
	isDefending  bool
	enemyDefend  bool
}

func NewGame() *Game {
	return &Game{
		state:      StateMenu,
		myHP:       100,
		myMaxHP:    100,
		enemyHP:    100,
		enemyMaxHP: 100,
		logLimit:   7,
		ipInput:    "127.0.0.1",
		potions:    3,
		p2Potions:  3,
		energy:     50,
		p2Energy:   50,
	}
}

func (g *Game) addLog(msg string) {
	g.mu.Lock()
	defer g.mu.Unlock()
	g.msgLog = append(g.msgLog, msg)
	if len(g.msgLog) > g.logLimit {
		g.msgLog = g.msgLog[1:]
	}
}

func (g *Game) resetStats(fullReset bool) {
	g.mu.Lock()
	defer g.mu.Unlock()
	if fullReset {
		g.storyStage = 0
	}
	g.myHP = 100
	g.myMaxHP = 100
	g.enemyMaxHP = 100 + (g.storyStage * 25)
	g.enemyHP = g.enemyMaxHP
	g.potions = 3
	g.p2Potions = 3
	g.energy = 50
	g.p2Energy = 50
	g.isDefending = false
	g.enemyDefend = false
	g.isHotseat = false
	g.isSingle = false
	g.lastError = ""
}

func (g *Game) handleConnection(conn net.Conn) {
	g.conn = conn
	g.mu.Lock()
	g.state = StatePlaying
	g.isSingle = false
	g.mu.Unlock()
	g.resetStats(true)
	reader := bufio.NewReader(conn)
	for {
		line, err := reader.ReadString('\n')
		if err != nil {
			g.addLog("SYSTEM: Connection lost.")
			return
		}
		line = strings.TrimSpace(line)
		if line != "" {
			g.processMessage(line)
		}
	}
}

func (g *Game) processMessage(msg string) {
	parts := strings.SplitN(msg, ":", 2)
	if len(parts) < 2 { return }
	cmd, payload := parts[0], parts[1]

	switch cmd {
	case "CHAT":
		g.addLog("FRIEND: " + payload)
	case "ATTACK":
		var dmg int
		fmt.Sscanf(payload, "%d", &dmg)
		g.mu.Lock()
		if g.isDefending {
			dmg /= 2
		}
		g.myHP -= dmg
		g.isDefending = false
		g.myTurn = true
		g.mu.Unlock()
		g.addLog(fmt.Sprintf("SYSTEM: Received %d damage!", dmg))
	case "HEAL":
		var amt int
		fmt.Sscanf(payload, "%d", &amt)
		g.mu.Lock()
		g.enemyHP += amt
		if g.enemyHP > g.enemyMaxHP { g.enemyHP = g.enemyMaxHP }
		g.myTurn = true
		g.mu.Unlock()
		g.addLog(fmt.Sprintf("SYSTEM: Enemy healed for %d!", amt))
	case "DEFEND":
		g.mu.Lock()
		g.enemyDefend = true
		g.myTurn = true
		g.mu.Unlock()
		g.addLog("SYSTEM: Enemy is defending!")
	}
}

func (g *Game) Update() error {
	// Global exit / return to menu
	if inpututil.IsKeyJustPressed(ebiten.KeyEscape) {
		if g.state == StateMenu {
			return ebiten.Termination // Exit app
		}
		if g.conn != nil {
			g.conn.Close()
			g.conn = nil
		}
		g.mu.Lock()
		g.state = StateMenu
		g.mu.Unlock()
		g.resetStats(true)
		return nil
	}

	g.mu.Lock()
	state := g.state
	myTurn := g.myTurn
	myHP := g.myHP
	enemyHP := g.enemyHP
	isSingle := g.isSingle
	isHotseat := g.isHotseat
	g.mu.Unlock()

	switch state {
	case StateMenu:
		if inpututil.IsKeyJustPressed(ebiten.KeyS) {
			g.resetStats(false)
			g.mu.Lock()
			g.state = StateStory
			g.isSingle = true
			g.myTurn = true
			g.mu.Unlock()
			g.addLog(fmt.Sprintf("CHAPTER %d: Start!", g.storyStage+1))
		}
		if inpututil.IsKeyJustPressed(ebiten.KeyP) {
			g.resetStats(true)
			g.mu.Lock()
			g.state = StateHotseat
			g.isHotseat, g.myTurn = true, true
			g.mu.Unlock()
			g.addLog("HOTSEAT MODE START")
		}
		if inpututil.IsKeyJustPressed(ebiten.KeyH) {
			g.mu.Lock()
			g.isHost, g.myTurn, g.state = true, true, StateWaiting
			g.mu.Unlock()
			go g.startServer()
		}
		if inpututil.IsKeyJustPressed(ebiten.KeyJ) {
			g.mu.Lock()
			g.typingIP = true
			g.mu.Unlock()
		}
		if g.typingIP {
			chars := ebiten.AppendInputChars(nil)
			g.mu.Lock()
			for _, c := range chars { g.ipInput += string(c) }
			if inpututil.IsKeyJustPressed(ebiten.KeyBackspace) && len(g.ipInput) > 0 {
				g.ipInput = g.ipInput[:len(g.ipInput)-1]
			}
			if inpututil.IsKeyJustPressed(ebiten.KeyEnter) {
				g.typingIP = false
				go g.startClient(g.ipInput)
			}
			g.mu.Unlock()
		}

	case StateStory, StatePlaying, StateHotseat:
		if state == StatePlaying {
			chars := ebiten.AppendInputChars(nil)
			g.mu.Lock()
			for _, c := range chars { g.inputStr += string(c) }
			if inpututil.IsKeyJustPressed(ebiten.KeyBackspace) && len(g.inputStr) > 0 {
				g.inputStr = g.inputStr[:len(g.inputStr)-1]
			}
			if inpututil.IsKeyJustPressed(ebiten.KeyEnter) && g.inputStr != "" {
				msg := "CHAT:" + g.inputStr
				g.mu.Unlock()
				g.send(msg)
				g.addLog("YOU: " + strings.TrimPrefix(msg, "CHAT:"))
				g.mu.Lock()
				g.inputStr = ""
			}
			g.mu.Unlock()
		}

		if myTurn && myHP > 0 && enemyHP > 0 {
			if g.handleCombat(true) {
				g.mu.Lock()
				g.myTurn = false
				g.enemyDefend = false
				g.mu.Unlock()
				if isSingle { go g.enemyAI() }
			}
		} else if isHotseat && !myTurn && myHP > 0 && enemyHP > 0 {
			if g.handleCombat(false) {
				g.mu.Lock()
				g.myTurn = true
				g.isDefending = false
				g.mu.Unlock()
			}
		}

		if myHP <= 0 || enemyHP <= 0 {
			if isSingle && enemyHP <= 0 {
				g.mu.Lock()
				g.storyStage++
				g.mu.Unlock()
				g.resetStats(false)
				g.mu.Lock()
				g.state = StateStory
				g.isSingle, g.myTurn = true, true
				g.mu.Unlock()
				g.addLog(fmt.Sprintf("CHAPTER %d!", g.storyStage+1))
			} else {
				g.mu.Lock()
				g.state = StateGameOver
				g.mu.Unlock()
			}
		}

	case StateGameOver:
		if inpututil.IsKeyJustPressed(ebiten.KeyR) {
			g.mu.Lock()
			g.state = StateMenu
			g.mu.Unlock()
			g.resetStats(true)
		}
	}
	return nil
}

func (g *Game) handleCombat(isP1 bool) bool {
	g.mu.Lock()
	hp, maxHP, energy, potions, isDef, targetHP, targetDef := &g.myHP, &g.myMaxHP, &g.energy, &g.potions, &g.isDefending, &g.enemyHP, &g.enemyDefend
	name := "P1"
	if !isP1 {
		hp, maxHP, energy, potions, isDef, targetHP, targetDef = &g.enemyHP, &g.enemyMaxHP, &g.p2Energy, &g.p2Potions, &g.enemyDefend, &g.myHP, &g.isDefending
		name = "P2"
	}
	isSingle := g.isSingle
	isHotseat := g.isHotseat
	g.mu.Unlock()

	actionTaken := false
	if inpututil.IsKeyJustPressed(ebiten.Key1) {
		dmg := 15 + rand.Intn(10)
		g.mu.Lock()
		if *targetDef { dmg /= 2 }
		*targetHP -= dmg
		g.mu.Unlock()
		g.addLog(fmt.Sprintf("%s attacks for %d damage!", name, dmg))
		if !isHotseat && !isSingle { g.send(fmt.Sprintf("ATTACK:%d", dmg)) }
		actionTaken = true
	}
	if inpututil.IsKeyJustPressed(ebiten.Key2) && *energy >= 20 {
		dmg := 30 + rand.Intn(15)
		g.mu.Lock()
		if *targetDef { dmg /= 2 }
		*targetHP -= dmg
		*energy -= 20
		g.mu.Unlock()
		g.addLog(fmt.Sprintf("%s: CRITICAL HIT! %d damage!", name, dmg))
		if !isHotseat && !isSingle { g.send(fmt.Sprintf("ATTACK:%d", dmg)) }
		actionTaken = true
	}
	if inpututil.IsKeyJustPressed(ebiten.Key3) && *potions > 0 && *hp < *maxHP {
		heal := 40
		g.mu.Lock()
		*hp += heal
		if *hp > *maxHP { *hp = *maxHP }
		*potions--
		g.mu.Unlock()
		g.addLog(fmt.Sprintf("%s used a POTION! (+%d HP)", name, heal))
		if !isHotseat && !isSingle { g.send(fmt.Sprintf("HEAL:%d", heal)) }
		actionTaken = true
	}
	if inpututil.IsKeyJustPressed(ebiten.Key4) {
		g.mu.Lock()
		*isDef = true
		*energy += 15
		if *energy > 100 { *energy = 100 }
		g.mu.Unlock()
		g.addLog(fmt.Sprintf("%s is DEFENDING!", name))
		if !isHotseat && !isSingle { g.send("DEFEND:true") }
		actionTaken = true
	}
	return actionTaken
}

func (g *Game) enemyAI() {
	g.mu.Lock()
	state := g.state
	myTurn := g.myTurn
	enemyHP := g.enemyHP
	g.mu.Unlock()

	if state == StateStory && !myTurn && enemyHP > 0 {
		time.Sleep(1000 * time.Millisecond)
		action := rand.Intn(10)
		
		var logMsgs []string
		
		g.mu.Lock()
		// Re-check state after sleep
		if g.state == StateStory && !g.myTurn && g.enemyHP > 0 {
			if g.enemyHP < g.enemyMaxHP/3 && action < 3 {
				heal := 15 + g.storyStage*2
				g.enemyHP += heal
				if g.enemyHP > g.enemyMaxHP { g.enemyHP = g.enemyMaxHP }
				logMsgs = append(logMsgs, fmt.Sprintf("ENEMY uses REPAIR! (+%d HP)", heal))
			} else if action < 7 {
				dmg := 8 + rand.Intn(12) + g.storyStage*2
				if g.isDefending { 
					dmg /= 2
					logMsgs = append(logMsgs, "You BLOCKED half damage!")
				}
				g.myHP -= dmg
				logMsgs = append(logMsgs, fmt.Sprintf("ENEMY deals %d damage!", dmg))
			} else {
				g.enemyDefend = true
				logMsgs = append(logMsgs, "ENEMY is DEFENDING!")
			}
			g.isDefending = false
			g.myTurn = true
		}
		g.mu.Unlock()

		for _, m := range logMsgs {
			g.addLog(m)
		}
	}
}

func (g *Game) startServer() {
	ln, err := net.Listen("tcp", ":"+port)
	if err != nil { 
		g.mu.Lock()
		g.lastError = "Port 8080 busy"; g.state = StateMenu
		g.mu.Unlock()
		return 
	}
	conn, _ := ln.Accept()
	g.handleConnection(conn)
}

func (g *Game) startClient(addr string) {
	conn, err := net.Dial("tcp", addr+":"+port)
	if err != nil { 
		g.mu.Lock()
		g.lastError = "Connection Failed!"
		g.mu.Unlock()
		return 
	}
	g.mu.Lock()
	g.isHost, g.myTurn = false, false
	g.mu.Unlock()
	g.handleConnection(conn)
}

func (g *Game) send(msg string) {
	g.mu.Lock()
	defer g.mu.Unlock()
	if g.conn != nil {
		fmt.Fprintln(g.conn, msg)
	}
}

func (g *Game) Draw(screen *ebiten.Image) {
	g.mu.Lock()
	defer g.mu.Unlock()

	screen.Fill(color.RGBA{10, 10, 15, 255})
	switch g.state {
	case StateMenu:
		ebitenutil.DebugPrintAt(screen, titleArt, 140, 50)
		vector.DrawFilledRect(screen, 250, 280, 300, 210, color.RGBA{30, 30, 50, 255}, false)
		ebitenutil.DebugPrintAt(screen, "[S] - SINGLE PLAYER (STORY)", 280, 300)
		ebitenutil.DebugPrintAt(screen, "[P] - HOTSEAT (LOCAL 2P)", 280, 330)
		ebitenutil.DebugPrintAt(screen, "[H] - HOST GAME (P2P)", 280, 360)
		ebitenutil.DebugPrintAt(screen, "[J] - JOIN GAME (ONLINE)", 280, 390)
		ebitenutil.DebugPrintAt(screen, "[ESC] - EXIT GAME", 280, 440)
		if g.typingIP { ebitenutil.DebugPrintAt(screen, "ENTER IP: "+g.ipInput+"_", 280, 415) }
		if g.lastError != "" { ebitenutil.DebugPrintAt(screen, "ERROR: "+g.lastError, 280, 470) }
	case StateWaiting:
		ebitenutil.DebugPrintAt(screen, "--- WAITING FOR PLAYER ---\nESC to Cancel", 300, 250)
	case StatePlaying, StateStory, StateHotseat:
		vector.StrokeRect(screen, 50, 50, 700, 350, 2, color.RGBA{100, 100, 150, 255}, false)
		ebitenutil.DebugPrintAt(screen, playerArt, 150, 180)
		g.drawBar(screen, 130, 300, g.myHP, g.myMaxHP, color.RGBA{0, 255, 0, 255})
		ebitenutil.DebugPrintAt(screen, fmt.Sprintf("HP: %d/%d", g.myHP, g.myMaxHP), 130, 320)
		g.drawBar(screen, 130, 340, g.energy, 100, color.RGBA{0, 200, 255, 255})
		if g.isDefending { ebitenutil.DebugPrintAt(screen, "[DEFENDING]", 130, 160) }
		ebitenutil.DebugPrintAt(screen, enemyArt, 550, 180)
		g.drawBar(screen, 530, 300, g.enemyHP, g.enemyMaxHP, color.RGBA{255, 0, 0, 255})
		ebitenutil.DebugPrintAt(screen, fmt.Sprintf("ENEMY HP: %d", g.enemyHP), 530, 320)
		if g.isHotseat { g.drawBar(screen, 530, 340, g.p2Energy, 100, color.RGBA{0, 200, 255, 255}) }
		if g.enemyDefend { ebitenutil.DebugPrintAt(screen, "[DEFENDING]", 530, 160) }
		if g.myTurn || g.isHotseat {
			vector.DrawFilledRect(screen, 280, 60, 240, 100, color.RGBA{40, 40, 60, 255}, false)
			ebitenutil.DebugPrintAt(screen, "--- YOUR TURN ---", 340, 70)
			ebitenutil.DebugPrintAt(screen, "[1] Atk [2] Hvy [3] Pot [4] Def", 290, 95)
			ebitenutil.DebugPrintAt(screen, "ESC: Menu", 360, 130)
		}
		vector.DrawFilledRect(screen, 50, 420, 700, 160, color.RGBA{20, 20, 30, 255}, false)
		for i, msg := range g.msgLog { ebitenutil.DebugPrintAt(screen, "> "+msg, 70, 435+(i*18)) }
		if g.state == StatePlaying { ebitenutil.DebugPrintAt(screen, "CHAT: "+g.inputStr+"_", 70, 560) }
	case StateGameOver:
		ebitenutil.DebugPrintAt(screen, "GAME OVER\nPress R for Menu or ESC to Quit", 330, 250)
	}
}

func (g *Game) drawBar(screen *ebiten.Image, x, y, val, max int, col color.RGBA) {
	width := 140.0
	fill := (float32(val) / float32(max)) * float32(width)
	if fill < 0 { fill = 0 }
	vector.DrawFilledRect(screen, float32(x), float32(y), float32(width), 10, color.RGBA{50, 50, 50, 255}, false)
	vector.DrawFilledRect(screen, float32(x), float32(y), fill, 10, col, false)
}

func (g *Game) Layout(w, h int) (int, int) { return screenWidth, screenHeight }

func main() {
	rand.Seed(time.Now().UnixNano())
	ebiten.SetWindowSize(screenWidth, screenHeight)
	ebiten.SetWindowTitle("CLOSED FRONTLINE")
	if err := ebiten.RunGame(NewGame()); err != nil { log.Fatal(err) }
}
